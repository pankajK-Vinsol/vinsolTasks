
// example with nested functions.
func makeIncrementerTwo(_ incrementAmount: Int) -> (Int) -> Int {
    func incrementTwice(_ incrementValue: Int) -> Int {
        return incrementValue + incrementAmount
    }
    return incrementTwice
}
// enter parameter value in makeIncrementer and tenIncrementer function according to your wish.

let fiveIncrementer = makeIncrementerTwo(5)
print(fiveIncrementer(9))


// example by use of closure.
func makeIncrementer(_ incrementAmount: Int) -> (Int) -> Int {
    return { finalAmount in incrementAmount + finalAmount}
}

let tenIncrementer = makeIncrementer(7)
print(tenIncrementer(6))
