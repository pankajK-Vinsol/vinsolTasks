
// example with nested functions.
func makeIncrementerTwo(_ incrementAmount: Int) -> (Int) -> Int{
    func incrementTwice(_ incrementVAlue: Int) -> Int{
        return incrementVAlue + incrementAmount
    }
    return incrementTwice(_:)
}
// enter parameter value in makeIncrementer and tenIncrementer function according to your wish.

let fiveIncrementer = makeIncrementerTwo(5)
print(fiveIncrementer(9))
