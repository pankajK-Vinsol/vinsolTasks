
func makeIncrementer(_ incrementAmount: Int) -> (Int) -> Int{
    return { finalAmount in incrementAmount + finalAmount}
}

// enter parameter value in makeIncrementer and tenIncrementer function according to your wish.
let tenIncrementer = makeIncrementer(10)
print(tenIncrementer(6))

