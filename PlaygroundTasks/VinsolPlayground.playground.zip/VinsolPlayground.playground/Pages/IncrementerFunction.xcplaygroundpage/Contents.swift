
//// example by use of closure.
//func makeIncrementer(_ incrementAmount: Int) -> (Int) -> Int{
//    return { finalAmount in incrementAmount + finalAmount}
//}

// example with nested functions.
func makeIncrementerTwo(_ incrementAmount: Int) -> (Int) -> Int{
    func incrementTwice(_ incrementVAlue: Int) -> Int{
        return incrementVAlue + incrementAmount
    }
    return incrementTwice(_:)
}

// enter parameter value in makeIncrementer and tenIncrementer function according to your wish.

//let tenIncrementer = makeIncrementer(7)
//print(tenIncrementer(6))

let fiveIncrementer = makeIncrementerTwo(5)
print(fiveIncrementer(9))
