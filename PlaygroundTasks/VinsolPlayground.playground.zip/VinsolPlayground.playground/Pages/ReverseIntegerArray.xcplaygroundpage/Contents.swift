
func reverseArr(_ intArray: [Int]) -> [Int] {
    var intArray = intArray
    var first = 0
    var last = intArray.count - 1
    while first < last {
        let temp = intArray[first]
        intArray[first] = intArray[last]
        intArray[last] = temp
        first += 1
        last -= 1
    }
    return intArray
}

// Enter the values of array according to your choice.
let passedArr: [Int] = [89, 56, 43, 23, 1, 9, 98]
print("Passed Integer array is: \(passedArr)")
print("The array after being reversed is: \(reverseArr(passedArr))")
