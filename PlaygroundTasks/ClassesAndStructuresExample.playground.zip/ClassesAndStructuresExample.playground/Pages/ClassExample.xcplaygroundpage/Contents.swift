
class Example {
// 1.instance variables
    var count = 0      // variable stored property
    let length = 7     // constant stored property
    let firstValue: Int
    var valueCount: Int
    var defaultInitValue: Int
    
// 3.initialization of two values not initialized on declaration.
    init(firstValue: Int, valueCount: Int) {
        self.firstValue = firstValue  // custom initializations
        self.valueCount = valueCount
        defaultInitValue = 12 // initialization - the default value of param is set 12.
    }
    
// 4.instance method
    func increment() {
        count += 1
    }
    
}

// 5.object initialization
let exampleObj = Example(firstValue: 0, valueCount: 5) // Class instance
exampleObj.valueCount = 7  // can be changed in class
//exampleObj.firstValue = 3  // cannot be changed as firstValue is initialized as constant in class.
print(exampleObj.valueCount); print(exampleObj.firstValue)

while exampleObj.count < exampleObj.length {
// 5.method call
    exampleObj.increment()
}
// 5.variable call
print(exampleObj.count)


// 2.example for computed property
class ComputedExample {
    var taskGoal = 0.0
    var taskCompleted = 0.0
// computed property
    var taskLeft: Double { // specifying type is must in computed property
      return taskGoal - taskCompleted
    }
// this one is for single getter property, so get keyword is not specified.
//2.
    var taskRemaining: Double {
        get {
            return taskGoal - taskCompleted
        }
        set(newUnitsLeft) {
            taskCompleted = taskGoal - newUnitsLeft
        }
// 2.Here newUnitsLeft value is set and from which we can calculate the taskCompleted value instead.
    }
}

let computedObj = ComputedExample()
computedObj.taskGoal = 20.0
computedObj.taskCompleted = 5.0
print(computedObj.taskLeft) // this computed property is calculated based on the other 2 instance properties value.

computedObj.taskRemaining = 8.5 // task remaining is set
print(computedObj.taskCompleted) // taskCompleted can be deduced from above.
