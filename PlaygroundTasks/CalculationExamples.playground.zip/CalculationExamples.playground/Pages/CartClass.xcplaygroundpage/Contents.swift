
class Category {
    var name: String
    var isTaxable: Bool
    init(name: String, isTaxable: Bool) {
        self.name = name
        self.isTaxable = isTaxable
    }
}
class Product {
    var name: String
    var isImported: Bool
    var price: Int
    var category: Category
    init(name: String, isImported: Bool, price: Int, category: Category) {
        self.name = name
        self.isImported = isImported
        self.price = price
        self.category = category
    }
}
class CartItem {
    var product: Product
    var quantity: Int
    init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = quantity
    }
}
class Cart {
    static let sharedInstance = Cart()
    var items = [CartItem]()
    var grandTotal = 0
    
    func add(productName: CartItem) {
        if items.count > 0 {
            for cartItem in items {
                if cartItem.product.name == productName.product.name {
                    cartItem.quantity += 1
                    break
                } else {
                    items.append(productName)
                }
            }
        } else {
            items.append(productName)
        }
    }
    
    func remove(productName: CartItem) {
            for (index, cartItem) in items.enumerated() {
            if cartItem.product.name == productName.product.name {
                if cartItem.quantity == 1 {
                    items.remove(at: index)
                } else {
                    cartItem.quantity -= 1
                }
            }
        }
    }
    
    func billAndTotalPrice() {
        print("Name         Price   Quantity   Tax   Total ")
        print("--------------------------------------------")
        for cartItem in items {
            let productTotal = cartItem.product.price * cartItem.quantity
            var totalTax = Double()
            
            if cartItem.product.isImported && cartItem.product.category.isTaxable {
                totalTax = 0.15
            } else if cartItem.product.isImported && !(cartItem.product.category.isTaxable) {
                totalTax = 0.05
            } else {
                totalTax = 0.10
            }
            
            let taxValue = Double(productTotal) * totalTax
            print("\(cartItem.product.name) \(cartItem.product.price)       \(cartItem.quantity)       \(Int(taxValue))    \(productTotal + Int(taxValue))")
            grandTotal += productTotal + Int(taxValue)
        }
    }
    func printGrandTotal() {
        print("--------------------------------------------")
        print("Grand Total: \(grandTotal)")
        print("--------------------------------------------")
    }
}

var category1 = Category(name: "Book", isTaxable: false)
var category2 = Category(name: "Food", isTaxable: false)
var category3 = Category(name: "Medicine", isTaxable: false)
var category4 = Category(name: "Chocolate", isTaxable: true)
var category5 = Category(name: "Stationary", isTaxable: true)

var product1 = Product(name: "Harry Potter", isImported: true, price: 2000, category: category1)
var product2 = Product(name: "Dairy Milk  ", isImported: false, price: 1000, category: category4)

var cartItem1 = CartItem(product: product1, quantity: 1)
var cartItem2 = CartItem(product: product2, quantity: 1)

Cart.sharedInstance.add(productName: cartItem1)
Cart.sharedInstance.remove(productName: cartItem1)
Cart.sharedInstance.add(productName: cartItem2)
Cart.sharedInstance.add(productName: cartItem1)
Cart.sharedInstance.billAndTotalPrice()
Cart.sharedInstance.printGrandTotal()
