
class Category {
    let name: String
    let isTaxable: Bool
    init(name: String, isTaxable: Bool) {
        self.name = name
        self.isTaxable = isTaxable
    }
}
class Product {
    let name: String
    let isImported: Bool
    var price: Int
    let category: Category
    init(name: String, isImported: Bool, price: Int, category: Category) {
        self.name = name
        self.isImported = isImported
        self.price = price
        self.category = category
    }
}
class CartItem {
    let product: Product
    var quantity: Int
    init(product: Product, quantity: Int) {
        self.product = product
        self.quantity = quantity
    }
}
class Cart {
    static let sharedInstance = Cart()
    var items = [CartItem]()
    var grandTotal = 0
    
    func add(item: Product) {
        guard items.count > 0 else {
            items.append(CartItem(product: item, quantity: 1))
            return
        }
        guard let cartItem = items.first(where: { $0.product.name == item.name }) else {
            items.append(CartItem(product: item, quantity: 1))
            return
        }
        cartItem.quantity += 1
    }
    
    func remove(item: Product) {
        for (index, cartItem) in items.enumerated() {
            if cartItem.product.name == item.name {
                guard cartItem.quantity == 1 else {
                    cartItem.quantity -= 1
                    return
                }
                items.remove(at: index)
            }
        }
    }
    
    func billAndTotalPrice() {
        print("Name         Price   Quantity   Tax   Total ")
        print("--------------------------------------------")
        for cartItem in items {
            let productTotal = cartItem.product.price * cartItem.quantity
            var percentTax: Double {
                if cartItem.product.isImported && cartItem.product.category.isTaxable {
                    return 0.15
                } else if cartItem.product.isImported && !(cartItem.product.category.isTaxable) {
                    return 0.05
                } else {
                    return 0.10
                }
            }
            let taxValue = Double(productTotal) * percentTax
            print("\(cartItem.product.name) \(cartItem.product.price)       \(cartItem.quantity)       \(Int(taxValue))    \(productTotal + Int(taxValue))")
            grandTotal += productTotal + Int(taxValue)
        }
    }
    func printGrandTotal() {
        print("--------------------------------------------")
        print("Grand Total: \(grandTotal)")
        print("--------------------------------------------")
    }
}

let category1 = Category(name: "Book", isTaxable: false)
let category2 = Category(name: "Food", isTaxable: false)
let category3 = Category(name: "Medicine", isTaxable: false)
let category4 = Category(name: "Chocolate", isTaxable: true)
let category5 = Category(name: "Stationary", isTaxable: true)

let product1 = Product(name: "Harry Potter", isImported: true, price: 2000, category: category1)
let product2 = Product(name: "Dairy Milk  ", isImported: false, price: 1000, category: category4)

Cart.sharedInstance.add(item: product1)
Cart.sharedInstance.remove(item: product1)
Cart.sharedInstance.add(item: product2)
Cart.sharedInstance.add(item: product1)
Cart.sharedInstance.billAndTotalPrice()
Cart.sharedInstance.printGrandTotal()
