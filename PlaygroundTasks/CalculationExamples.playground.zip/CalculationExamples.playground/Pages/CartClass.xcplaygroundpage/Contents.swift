
class Category {
    var name: String
    var taxApplied: Bool
    init(name: String, taxApplied: Bool) {
        self.name = name
        self.taxApplied = taxApplied
    }
}
class Product {
    var name: String
    var importedCheck: Bool
    var price: Int
    var category: Category
    var quantity: Int
    init(name: String, imported: Bool, price: Int, category: Category) {
        self.name = name
        self.importedCheck = imported
        self.price = price
        self.category = category
        self.quantity = 1
    }
}
class Cart {
    static let sharedInstance = Cart()
    var cartValueArray = [Product]()
    var grandTotal = 0
    
    func store(productName: Product) {
        self.cartValueArray.append(productName)
    }
    func add(productName: Product) {
        for cartItem in Cart.sharedInstance.cartValueArray {
            if cartItem.name == productName.name {
                cartItem.quantity += 1
            }
        }
    }
    func remove(productName: Product) {
        for index in 0 ... Cart.sharedInstance.cartValueArray.count - 1 {
            let cartItem = Cart.sharedInstance.cartValueArray[index]
            if cartItem.name == productName.name {
                if cartItem.quantity == 1{
                    Cart.sharedInstance.cartValueArray.remove(at: index)
                } else {
                    cartItem.quantity -= 1
                }
            }
        }
    }
    func billAndTotalPrice() {
        for cartItem in Cart.sharedInstance.cartValueArray {
            print("Name: \(cartItem.name)")
            print("Price: \(cartItem.price)")
            print("Quantity: \(cartItem.quantity)")
            let productTotal = cartItem.price * cartItem.quantity
            var totalTax = Double()
            if cartItem.importedCheck && cartItem.category.taxApplied {
                totalTax = 0.15
            } else if cartItem.importedCheck && !(cartItem.category.taxApplied) {
                totalTax = 0.05
            } else {
                totalTax = 0.10
            }
            let taxValue = Double(productTotal) * totalTax
            print("Total Tax: \(Int(taxValue))")
            print("Product Total: \(productTotal + Int(taxValue))")
            grandTotal += productTotal + Int(taxValue)
        }
    }
    func printGrandTotal() {
        print("Grand Total: \(grandTotal)")
    }
}

var category1 = Category(name: "Book", taxApplied: false)
var category2 = Category(name: "Food", taxApplied: false)
var category3 = Category(name: "Medicine", taxApplied: false)
var category4 = Category(name: "Chocolate", taxApplied: true)
var category5 = Category(name: "Stationary", taxApplied: true)

var product1 = Product(name: "Harry Potter", imported: true, price: 2000, category: category1)
var product2 = Product(name: "Dairy Milk", imported: false, price: 500, category: category4)

Cart.sharedInstance.store(productName: product1)
Cart.sharedInstance.store(productName: product2)
Cart.sharedInstance.add(productName: product1)
Cart.sharedInstance.remove(productName: product1)
Cart.sharedInstance.add(productName: product2)
Cart.sharedInstance.billAndTotalPrice()
Cart.sharedInstance.printGrandTotal()
