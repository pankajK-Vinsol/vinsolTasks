
class Cart {
    static let sharedInstance = Cart()
    var qunatity: Int = 0
    var productName: String = ""
    var price: Int = 0
    var categoryName: String = ""
    var imported: Bool = false
    var salesTax: Bool = false
    var grandTotal = 0
    private init() { }
    
    func add(productName: String) {
        if Cart.sharedInstance.productName == productName {
            Cart.sharedInstance.qunatity += 1
        }
    }
    func remove(productName: String) {
        if Cart.sharedInstance.productName == productName {
            Cart.sharedInstance.qunatity -= 1
        }
    }
    func billAndTotalPrice() {
        print("Name: \(Cart.sharedInstance.productName)")
        print("Price: \(Cart.sharedInstance.price)")
        print("Quantity: \(Cart.sharedInstance.qunatity)")
        let productTotal = Cart.sharedInstance.price * Cart.sharedInstance.qunatity
        var totalTax = Double()
        if Cart.sharedInstance.imported == true && Cart.sharedInstance.salesTax == true {
            totalTax = 0.15
        } else if Cart.sharedInstance.imported == true && Cart.sharedInstance.salesTax == false {
            totalTax = 0.05
        } else {
            totalTax = 0.10
        }
        let taxValue = Double(productTotal) * totalTax
        print("Total Tax: \(Int(taxValue))")
        print("Product Total: \(productTotal + Int(taxValue))")
        grandTotal += productTotal + Int(taxValue)
    }
    func printGrandTotal() {
        print("Grand Total: \(grandTotal)")
    }
}

let product1 = Cart.sharedInstance
product1.qunatity = 1
product1.productName = "Harry Potter"
product1.price = 1000
product1.categoryName = "Books"
product1.imported = false
product1.salesTax = true
product1.add(productName: "Harry Potter")
product1.remove(productName: "Harry Potter")
product1.billAndTotalPrice()

let product2 = Cart.sharedInstance
product2.categoryName = "Stationary"
product2.productName = "Notebook"
product2.price = 500
product2.imported = true
product2.qunatity = 1
product2.salesTax = false
product2.add(productName: "Notebook")
product2.add(productName: "Notebook")
product2.remove(productName: "Notebook")
product2.billAndTotalPrice()
Cart.sharedInstance.printGrandTotal()
