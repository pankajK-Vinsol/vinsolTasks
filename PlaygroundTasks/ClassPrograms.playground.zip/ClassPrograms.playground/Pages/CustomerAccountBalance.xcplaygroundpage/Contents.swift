
class Customer {
    let name: String
    var accountNo: Int?
    var balance = 1000
    init(name: String) {
        self.name = name
    }
    func increment() {
        accNumber += 1
        accountNo = accNumber
    }
    func deposit(_ depositAmt: Int) -> Int {
        balance += depositAmt
        return balance
    }
    func withDraw(_ withDrawAmt: Int) -> Int {
        balance -= withDrawAmt
        return balance
    }
}

var accNumber = 0
let customerObj1 = Customer(name: "Pankaj")
customerObj1.increment()
print("Our customer \(customerObj1.name) with account No. \(customerObj1.accountNo ?? 0) has balance \(customerObj1.balance) left.")
customerObj1.deposit(100)
print("\(customerObj1.name) amount after deposit is \(customerObj1.balance)")
customerObj1.withDraw(200)
print("\(customerObj1.name) amount after withdraw is \(customerObj1.balance)")

let customerObj2 = Customer(name: "Swati")
customerObj2.increment()
print("Our customer \(customerObj2.name) with account No. \(customerObj2.accountNo ?? 0) has balance \(customerObj2.balance) left.")
customerObj2.deposit(500)
print("\(customerObj2.name) amount after deposit is \(customerObj2.balance)")
customerObj2.withDraw(300)
print("\(customerObj2.name) amount after withdraw is \(customerObj2.balance)")
