
class Customer {
    let accountNo: Int
    let name: String
    
    private(set) var balance = 1000.0
    static var initialAccountNo = 10000

    init(name: String) {
        self.name = name
        self.accountNo = Customer.initialAccountNo
        Customer.initialAccountNo += 1
    }

    func deposit(amount: Double) -> Double {
        balance += amount
        return balance
    }
    func withDraw(amount: Double) -> (Double, String) {
        if amount <= balance {
            balance -= amount
            return (balance, "Withdraw successful")
        } else {
            return (balance, "Not Sufficient Balance")
        }
    }
}

let customerObj1 = Customer(name: "Pankaj")
print("Our customer \(customerObj1.name) with account No. \(customerObj1.accountNo) has balance \(customerObj1.balance) left.")
print(customerObj1.deposit(amount: 100))
print(customerObj1.withDraw(amount: 1200))

let customerObj2 = Customer(name: "Pankaj2")
print("Our customer \(customerObj2.name) with account No. \(customerObj2.accountNo) has balance \(customerObj2.balance) left.")
print(customerObj2.deposit(amount: 100))
print(customerObj2.withDraw(amount: 200))
