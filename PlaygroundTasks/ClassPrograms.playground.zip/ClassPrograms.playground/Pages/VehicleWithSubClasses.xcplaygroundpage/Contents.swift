
class Vehicle {
    var name: String
    var price: Int
    init(name:String, price: Int) {
        self.name = name
        self.price = price
    }
    func contents() {
        print("The Vehicle name is \(name) and is priced at \(price)")
    }
    func changePrice(_ changeValue: Int) -> Int {
        price += changeValue
        return price
    }
}

class Bike: Vehicle {
    var dealer: String
    init(dealer: String, name: String, price: Int) {
        self.dealer = dealer
        super.init(name: name, price: price)
    }
    override func contents() {
        print("The vehicle \(name) sold by dealer \(dealer) is priced at \(price)")
    }
}

var bikeObject = Bike(dealer: "Yamaha", name: "Classic", price: 50000)
bikeObject.contents()
bikeObject.changePrice(2000)
bikeObject.contents()
