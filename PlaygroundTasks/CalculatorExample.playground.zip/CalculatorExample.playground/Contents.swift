
func calculator(leftValue: Double, rightValue: Double, operatorValue: String) -> Double {
    switch operatorValue {
        case "+":
        return leftValue + rightValue
        case "-":
        return leftValue - rightValue
        case "*":
        return leftValue * rightValue
        case "/":
        if rightValue == 0 {
            return 0
        } else {
            return leftValue / rightValue
        }
    default:
        return 0
    }
}

print(calculator(leftValue: 12, rightValue: 3, operatorValue: "/"))
