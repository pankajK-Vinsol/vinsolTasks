
enum CalculatorOperation {
    case add
    case subtract
    case multiply
    case divide
    init?(from buttonTitle: String) {
        switch buttonTitle {
        case "+": self = .add
        case "-": self = .subtract
        case "*": self = .multiply
        case "/": self = .divide
        default: return nil
        }
    }
    
    func apply(to left: Double, and right: Double) -> Double { //provided argument labels for practice example.
        switch self {
        case .add:
            return left + right
        case .subtract:
            return left - right
        case .multiply:
            return left * right
        case .divide:
            if right == 0 {
                return 0
            } else {
                return left / right
            }
        }
    }
}

var calculateEnumObj  = CalculatorOperation(from: "/")
print(calculateEnumObj?.apply(to: 23, and: 12) ?? 0)
print(calculateEnumObj?.apply(to: 12, and: 0) ?? 0)

