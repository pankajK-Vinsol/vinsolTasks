
func logger(closure: () -> Void) {
    print("Running MyFunc")
    closure()
}

logger {
    print("MyFunc Done")
}


// one more example
func method(arg: Bool, completion: (Bool) -> ()) {
    print("First line of code executed")
    completion(arg)
}

method(arg: true, completion: { (success) -> Void in
    print("Second line of code executed")
    if success {
        print("true")
    } else {
        print("false")
    }
})
