
func minMax(_ values: [Int]) -> (min: Int, max: Int)? {
    if values.count > 0 {
        var min = values[0]
        var max = values[0]
        for value in values {
            if value < min {
                min = value
            } else if value > max {
                max = value
            }
        }
        return(min, max)
    } else {
        return nil
    }
}

func minyMaxy(_ value1: Int, value2: Int) -> (min: Int, max: Int)? {
    if value1 > value2 {
        return(value2, value1)
    } else if value2 > value1 {
        return(value1, value2)
    } else {
        print("Both are equal!!")
        return nil
    }
}

print(minMax([12, 89, 9, 34, 56, 78, 89, 123, 90, 1200]) ?? [])
print(minyMaxy(12, value2: 122) ?? 0)
