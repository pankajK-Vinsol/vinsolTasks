
func minyMaxy(value1: Int, value2: Int) -> (min: Int, max: Int)? {
    if value1 > value2 {
        return(value2, value1)
    } else if value2 > value1 {
        return(value1, value2)
    } else {
        print("Both are equal!!")
        return nil
    }
}

print(minyMaxy(value1: 12, value2: 122)!)
