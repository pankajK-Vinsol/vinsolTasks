
func charactersFrequency(_ value: [String]) {
    var charactersCountDict: [Character: Int] = [:]
    for pickedValue in value {
        for characterChoose in pickedValue {
            let valueCount = charactersCountDict[characterChoose] ?? 0
            charactersCountDict.updateValue(valueCount + 1, forKey: characterChoose)
        }
    }
    print(charactersCountDict)
}
charactersFrequency(["String", "Vinsol", "Developer", "Software"])

func charactersFrequnecyString(_ words: String...) { // variadic parameter example
    var charactersCountDict: [Character: Int] = [:]
    for pickedValue in words {
        for characterChoose in pickedValue {
            let valueCount = charactersCountDict[characterChoose] ?? 0
            charactersCountDict.updateValue(valueCount + 1, forKey: characterChoose)
        }
    }
    print(charactersCountDict)
}
charactersFrequnecyString("vinsol")
charactersFrequnecyString("vinsol", "string", "integer", "counting", "numbers")
