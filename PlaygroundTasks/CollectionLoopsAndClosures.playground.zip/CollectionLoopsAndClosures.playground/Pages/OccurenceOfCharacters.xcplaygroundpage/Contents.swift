
func charactersFrequency(_ value: [String]) {
    var charactersCountDict: [Character: Int] = [:]
    for pickedValue in value {
        for characterChoose in pickedValue {
            if charactersCountDict.keys.contains(characterChoose) {
                guard let countValue = charactersCountDict[characterChoose] else { return }
                charactersCountDict.updateValue(countValue + 1, forKey: characterChoose)
            } else {
                charactersCountDict.updateValue(1, forKey: characterChoose)
            }
        }
    }
    print(charactersCountDict)
}

charactersFrequency(["String", "Vinsol", "Developer", "Software"])
//charactersFrequency(["DDevelopers"])
//charactersFrequency([])
