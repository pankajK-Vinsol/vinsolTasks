
func fibonacciValue(_ value: Int) -> Int {
    var fiboArray: [Int] = []
    fiboArray = [1, 1]
    if value > 1 {
        for i in 2 ..< value {
            fiboArray.append(fiboArray[i - 1] + fiboArray[i - 2])
        }
        return fiboArray[value - 1]
    } else {
        return fiboArray[value]
    }
}

// enter the value in function as required
print(fibonacciValue(11))
