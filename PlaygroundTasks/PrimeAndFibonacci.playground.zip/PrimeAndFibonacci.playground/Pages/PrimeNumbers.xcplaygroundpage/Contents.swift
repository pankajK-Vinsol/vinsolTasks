
func getPrimeNumbers(_ count: Int) -> [Int]{
    var primeArray: [Int] = []
    var index = 0
    var start = 2
    var flag = true
    while index < count {
        for i in 2 ..< start {
            if start % i == 0 {
                flag = false
                break
            } else {
                flag = true
            }
        }
        if flag {
            primeArray.append(start)
            index += 1
        }
        start += 1
    }
    return primeArray
}

// enter the value in function as required.
print(getPrimeNumbers(34))
